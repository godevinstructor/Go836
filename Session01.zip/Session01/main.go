package main

import "fmt"

func main() {

	points := 80

	switch {
	case points >= 70:
		fmt.Println("Certified")
		fallthrough
	case points >= 60 :
		fmt.Println("Retake with '50%'")
	default : 
		fmt.Println("Fail")
	}

	// gofmt -w main.go   Format Code Style
	// key := 1
	// switch key {
	// case 0:
	// 	fmt.Println("The Key is Off")
	// case 1:
	// 	fmt.Println("The key is on")
	// default:
	// 	fmt.Println("Invalid Number")
	// }
}
