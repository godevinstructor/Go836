package main

import (
	"fmt"
	"slices"
	// "my-app/src"
)

func main() {
	// fmt.Println(src.Factorial(4))
	// len cap
	// a b c

	// letters := []string{} // Memory Allocation
	// fmt.Println(letters == nil , cap(letters) , len(letters))

	// var nums []int // nil slice avoid heap allocation
	// fmt.Println(nums == nil , cap(nums) , len(nums))

	// nums := make([]int, 0 , 4)
	// // nums[2] = 5
	// nums = append(nums , 10 , 20)
	// fmt.Println(nums)
	/*
		Backing Array : [0  , 0 , 10 , _ ]
		Slice : [0  , 0]
		Len : 2
		Cap : 4
	*/

	// original := []int{1 , 2 , 3 , 4 , 5}
	// sub := original[1 : 3] // [2 , 3] Share The Same Underlying array
	// sub[0] = 100
	// fmt.Println(original)

	// s1 := []int{1 , 2}
	// s2 := [] int{4 ,4}
	// all := append(s1 , s2...) // all {1 , 2 , 3 , 4}
	// fmt.Println(s1 , s2 , all )

	// Copy Slices
	// Everything In Go Pass By Value
	// x := []int{1, 2, 3}
	// y := make([]int, len(x))
	// //x[0] = 100
	// copy(y, x)
	// // x[0] = 100
	// fmt.Println(x)

	// Iterate Over Slices
	// languages :=  []string{"Go" , "js" , "c#"}
	// for _ , lang :=range languages {
	// 	fmt.Println(lang)
	// }

	nums := []int{100, 200, 300, 400}
	// nums = nums[1:] //
	// nums = nums[ : len(nums) - 1]
	// nums = append(nums[ : 1] , nums[2:]...)
	// fmt.Println(nums)
	nums = slices.Delete(nums , 1 , 3)
	fmt.Println(nums)
}
