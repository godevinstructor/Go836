module my-app

go 1.27.0
