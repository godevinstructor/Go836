package src

import "fmt"

/*
	Recusrion function call itself
	Base Call
	Recusive Part

	Problem => Small 
*/
func CountDown(num int) { 
	if(num < 1) { 
		return
	}
	fmt.Println(num)
	CountDown(num - 1)
}

func Factorial(num int) int { 
	if num == 1 { 
		return 1
	}
	return num * Factorial(num - 1)
}
/*
Stack
	Factorial(4)
	4 * factorial(3)
	3 * factorial(2)
	2 * factorial(1)
	4 * 3 * 2 * 1

*/

// Reverse String using Recursion (Slice + REcursion)
// Hello olleh
// Fibonacci Series => Recusrion