package src

// name := "Huda"
// fmt.Println(&name)
// /*
// 	name     address     value
// 	name      0x00100     huda
// */
// name2 := name
// name = "Ali"
// fmt.Println(name2)

// num := 50
// p := &num
// fmt.Println(*p)

// x := 4
// increment(&x)
// fmt.Println("x" , x)

// func increment(num *int) {
// *num += 1
// fmt.Println("Inside Increment : " , *num)
// }
