let obj1 = {x : 1}
let obj2 
obj2 = obj1
obj2.x = 2
console.log(obj2)