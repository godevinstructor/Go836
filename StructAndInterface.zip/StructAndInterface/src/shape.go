package src

// // // import (
// // // 	"fmt"
// // // 	"math"
// // // )

// // // type IShape interface {
// // // 	Area() float64
// // // 	Perimeter() float64
// // // }

// // // type Circle struct {
// // // 	Radius float64
// // // }

// // // type Square struct {
// // // 	Side float64
// // // }

// // // func (c Circle) Area() float64 {
// // // 	return math.Pi * math.Pow(c.Radius, 2)
// // // }

// // // func (c Circle) Perimeter() float64 {
// // // 	return math.Pi * c.Radius * 2
// // // }

// // // func (sq Square) Area() float64 {
// // // 	return math.Pow(sq.Side, 2)
// // // }

// // // func (sq Square) Perimeter() float64 {
// // // 	return sq.Side * 4
// // // }

// // // func ShowDetails(s IShape) {
// // // 	fmt.Println("Area = ", s.Area())
// // // 	fmt.Println("Perimeter = ", s.Perimeter())
// // // }

// // // func main() {
// // // 	c := Circle{Radius: 8}
// // // 	sq := Square{10}
// // // 	ShowDetails(c)
// // // 	ShowDetails(sq)
// // // }

// // type IShape interface {
// // 	Area() float64
// // }

// // type Circle struct {
// // 	Radius float64
// // }

// // type Square struct {
// // 	Side float64
// // }

// // type  Rectangle struct { 
// // 	Length , Width float64
// // }

// // func (rect Rectangle) Area() float64 { 
// // 	return rect.Length * rect.Width
// // }

// // func (c Circle) Area() float64 {
// // 	return math.Pi * math.Pow(c.Radius, 2)
// // }

// // func (sq Square) Area() float64 {
// // 	return math.Pow(sq.Side, 2)
// // }

// // func CalcTotalAreas(shapes []IShape) float64 { 
// // 	total := 0.0
// // 	for _ , shape := range shapes { 
// // 		total += shape.Area()
// // 	}
// // 	return total
// // }

// // func LargestShape(shapes []IShape) IShape { 
// // 	var largestShape IShape
// // 	for _ , shape := range shapes { 
// // 		if largestShape == nil || shape.Area() > largestShape.Area() { 
// // 			largestShape = shape
// // 		}
// // 	}
// // 	return largestShape
// // }
// 	shapes := []IShape { 
// 		Circle{Radius: 12} , 
// 		Rectangle{Length: 10 , Width: 20} , 
// 		Square{Side: 5},
// 	}
// 	fmt.Println(CalcTotalAreas(shapes))
// 	fmt.Println(LargestShape(shapes))