package src
type User struct { 
	Username string `json:"user"`
	Email string `json:"email"`
	Password string `json:"password"`
	PhoneNumber string `json:"phone,omitempty"` // Omit if zero value
}

// Struct Tags (MetaData String Atatch to Fields)
// func main()  {
// 	user := User{Username: "Ahmed" , Email: "ahmed@ahmed.com" , 
// 	Password: "ahmed"}
// 	// {"user" : "" , "email"}
// 	data , _ := json.Marshal(user)
// 	fmt.Println(string(data))

// }