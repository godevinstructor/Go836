package src

// // import "fmt"

// type User struct {
// 	Id       int
// 	Username string
// 	email    string
// }
// // Value Reciever
// func (u User) GetUsername() string { 
// 	return u.Username
// }

// // func main() {
// // 	user1 := User{1, "Huda", "huda@yahoo.com"}
// // 	user2 := user1
// // 	user2.Username = "Ahmed"
// // 	// user2 := User{2, "Waheed", "waheed@yahoo.com"}
// // 	fmt.Println(user1.GetUsername() , user2)
// // }

// package main

// import "fmt"

// // type Student struct {
// // 	Name   string
// // 	points float64
// // }

// type ProjectTeam struct { 
// 	Name string
// 	Members []string
// }


// func main() {
// 	pt := ProjectTeam { 
// 		Name : "" , 
// 		Members : []string{"" , ""} ,
// 	}
// 	fmt.Println(pt)

// 	// Anonymous Struct
// 	st := struct { X int } {1}
// 	fmt.Println(st)
// 	// Value Type
// 	// std1 := Student{"", 1.0}
// 	// std2 := Student{"", 1.0}
// 	// fmt.Println(std1 == std2)
// 	// Return Pointer // Point Zero Value Struct
// 	// std2 := new(Student)
// }

// type Engine struct { }
// type Abc struct { }

// type Car struct {
// 	Engine
// 	Abc
// }

// type Address struct {
// 	Street  string
// 	City    string
// 	Country string
// }
// // Nested Data  / Nested Structs (Embeded Structs)
// // Composition
// type Employee struct {
// 	Name    string
// 	Salary  int
// 	Address // Embeded Struct
// }

// func main() {
// 	emp := Employee{
// 		Name:   "Ahmed",
// 		Salary: 100000,
// 		Address:Address{"x", "y", "z"},
// 	}
	
// 	fmt.Println(emp)
// }
