package main

// func SumIntNumbers(nums []int) int { 
// 	total := 0
// 	for _ , v := range nums { 
// 		total += v
// 	}
// 	return total
// }
// func SumFloatNumbers(nums []float64) float64 {
// 	total := 0.0
// 	for _ , v := range nums { 
// 		total += v
// 	}
// 	return total
// }
// any alias interface {}
// func PrintValue[T any](v T) {}
// Reusable Across All Functions
type Number interface { 
	int | int32 | int8 | int64 | float32 | float64
}

func sumNumbers[T Number](nums []T) T { 
	var total T
	for _ , v := range nums { 
		total += v
	}
	return total
}


func main() {
	// PrintValue("Hello")
	// PrintValue(10)
	// PrintValue(true)
}