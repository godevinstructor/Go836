package main

import (
	"fmt"
	"my-app/src"
)

func counter() func() int {
	count := 0
	return func() int {
		count++
		return count
	}
}

// Higher Order Function
func testOp(num int, f func(int) int) int {
	return f(num)
}

/*
result[0] = 2
result[1] = 4
result[2] = 6
result[3] = 8
[2 , 4 , 6 , 8]

/*

	func FilterIntNums(nums[]int , predicate func(int) bool)[]int {
		var result []int // nil slice [2 , 4 , 5]
		for _ , num :=range nums {
			if(predicate(num)) {
				result = append(result, num)
			}
		}
		return result
	}
	func ReduceIntNums(nums []int , initial int , reducer func(acc , curr int) int) int {
	acc := initial
	for _ , v := range nums { 
		acc = reducer(acc , v)
	}
	return acc
} 
*/

func main() {
	fmt.Println("Working With Higher Order Functions")
	nums := []int {10 , 20 , 60 , 30 , 40}

	mul := src.ReduceIntNums(nums , 1 , func(acc, curr int) int {
		return acc * curr
	})

	max := src.ReduceIntNums(nums , nums[0] , func(acc , curr int) int { 
		if curr > acc { 
			return curr
		}
		return acc
	})
	fmt.Println(max , mul)
	add := src.ReduceIntNums(nums , 0 , func(acc , curr int) int{ 
		return acc + curr
	})
	fmt.Println(add)

	// nums := []int{-1, 2, -3, 4, 0, 5}
	// positiveNums := src.FilterIntNums(nums, func(num int) bool {
	// 	return num > 0
	// })
	// evenNums := src.FilterIntNums(nums, func(num int) bool {
	// 	return num %2 == 0
	// })
	// fmt.Println(positiveNums, evenNums)
	// doubledNums := src.MapIntNums(nums , func(num int) int {
	// 	return num * 2
	// })
	// bonusNumbers := src.MapIntNums(nums , func(num int) int {
	// 	return num + 100
	// })
	// fmt.Println(doubledNums , bonusNumbers) // Dry
	// First Class Citzen
	// mulByFive := func(num int) int {return num * 5}
	// double := func(num int) int { return num * num}
	// fmt.Println(testOp(10 , mulByFive))
	// fmt.Println(testOp(10 , double))

	// Higher Order Function
	// function take another function as an argument
	// function return another function

	// count1 := counter()
	// count2 := counter()

	// fmt.Println(count1()) // 1
	// fmt.Println(count1()) // 2
	// fmt.Println(count2()) // 1
}
