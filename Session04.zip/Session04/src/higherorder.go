package src

// [1 , 2 , 3  ,4] return new [2 , 4 , 6 , 8]
func MapIntNums(nums []int, f func(int) int) []int {
	result := make([]int, len(nums))
	for index, num := range nums {
		result[index] = f(num)
	}
	return result
}

// Filter filteredArr = arr.filter(v => true)
// [10 , 8 , 17 , 2] => new slice num < 10 [8 , 2]

func FilterIntNums(nums []int, predicate func(int) bool) []int {
	var result []int // nil slice
	for _, num := range nums {
		if predicate(num) {
			result = append(result, num)
		}
	}
	return result
}

// Reduce [2 , 3 , 4 , 5] string ["Hello" , "World" , "Go"]
// Min Or Max
// initial , (acc , curr)
// [10 , 20]
func ReduceIntNums(nums []int , initial int , 
	reducer func(acc , curr int) int) int {
	acc := initial
	for _ , curr := range nums { 
		acc = reducer(acc , curr)
	}
	return acc
} 

// Find FindIndex Some Every