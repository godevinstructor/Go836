package main

import "fmt"

// type Rectangle struct {
// 	Height, Width int
// }

// Value Reciever
// func (r Rectangle) Area() int {
// 	return r.Height * r.Width
// }

// func (r Rectangle) Perimeter() int {
// 	return (r.Height + r.Width) * 2
// }

// func (r Rectangle) printDetails() {
// 	fmt.Println("Area ", r.Area())
// }
type Address struct { 
	street string
	city string
	country string
}
// Nested Structs
type Person struct {
	Name string 
	Age int
	Address Address
}

// func IncrementAge(p *Person) { 
// 	p.Age++;
// }

func main() {
	p := Person { 
		Name : "Abouelftouh" ,
		Age : 24 , 
		Address: Address{
			street: "a",
			city: "b",
			country: "b",
		},
	}

	fmt.Println(p)
	// p := Person{Age : 25}
	// IncrementAge(&p)
	// fmt.Println(p)
	// rect := Rectangle{Width: 10, Height: 50}
	// fmt.Println(rect.Area())
	// rect.printDetails()
}
