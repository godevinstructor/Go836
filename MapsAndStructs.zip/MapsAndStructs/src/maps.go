package src

// Syntaxt
	// map[KeyType]valuetype
	// student := map[string]string{
	// 	"id":     "12345",
	// 	"name":   "Hazem",
	// 	"points": "80",
	// 	"city":   "Cairo",
	// }
	// _, ok := student["id"]
	// fmt.Println(ok)

	// keys := make([]string, 0, len(student))

	// for k := range student {
	// 	keys = append(keys, k)
	// }
	// fmt.Println(keys)
	// sort.Strings(keys)

	// for _, key := range keys {
	// 	fmt.Println(key, student[key])
	// }
	// sort.Strings()

	// var users map[string]string
	// fmt.Println(users == nil)

	// for _ , v := range student {
	// 	fmt.Println(v)
	// }
