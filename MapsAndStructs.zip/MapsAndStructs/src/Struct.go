package src
// import "fmt"

// Struct (Structure) Similar to classes
/*
	Composite Data Type => Groups Related Fields into
	A Single Unit
	= Complex Data Model
	Exported (Public) Uppercase UnExported 	(Lowercase)
*/
type Student struct {
	Name    string
	Address string
	Age     int
}

// type User struct { }
// type Product struct { }

	// Struct Values
	// std1 := Student{Name: "Ahmed", Address: "Cairo", Age: 20}
	// std2 := std1 // Full Copy
	// std2.Name = "Waheed"
	// // std2 := Student {Name : "Ali" , Address: "Alex" , Age: 40}
	// // var std3 Student
	// fmt.Println(std1, std2)
	// std4 := new(Student)
	// //  Address Zero Value Struct Return Pointer Target Memory Address
	// std4.Name = "Mahmoud"
	// std4.Age = 30
	// std4.Address = "Alex"
	// fmt.Println(std4)
