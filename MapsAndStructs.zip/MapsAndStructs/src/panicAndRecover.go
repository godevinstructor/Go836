package src

import "fmt"
// func testPanic() {
// 	defer func() {
// 		if r := recover(); r != nil {
// 			fmt.Println("Recover Panic : ", r)
// 		}
// 	}()
// 	// Trigger Run Time Panic
// 	panic("Something Wrong")
// 	fmt.Println("Welcome")
// }
func divide(a, b int) {
	defer func() {
		if v := recover(); v != nil {
			fmt.Println("Error ", v)
		}
	}()
	if b == 0 {
		panic("Please Cannot Divide By Zero")
	}
	fmt.Println(a / b)
}

	// // testPanic()
	// divide(6, 0)
	// fmt.Println("Welcome To Huda")
	// x := 10
	// fmt.Println(x)