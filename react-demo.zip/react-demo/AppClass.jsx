import { Component } from "react";
class App extends Component {
  state = { 
    title : "React Demo" ,
    count : 0 , 
    students : ["Akram" , "Amgad" , "Ahmed"]
  } 

  changeTitleValue = () => { 
    this.setState({title : "React Project"})
  }

  componentDidMount() { }
  componentDidUpdate() { }
  componentWillUnmount()  {}
  render() { 
    return (
      <>
          <button onClick={this.changeTitleValue}>Change title</button>
          <h1> {this.state.title} </h1>
          <button onClick={() => this.setState({count : this.state.count + 1})}>
            Increment</button>
          <button onClick={() => this.setState({count : this.state.count - 1})}>Decrement</button>
          <h2>Count : {this.state.count} </h2>
      </>
    );
  }
}
 
export default App;