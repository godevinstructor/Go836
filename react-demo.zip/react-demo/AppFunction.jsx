import { useEffect, useState } from "react";
import useFetch from "./src/hooks/useFetch";

function App() {
  // React Hooks
  const [count , setCount] = useState(0)
  const [title , setTitle] = useState("React Demo")
  // const [users , setUsers] = useState([])
  const users = useFetch("url")
  const products = useFetch("")
  // On State Changes
  useEffect(() => { console.log(count)} , [count])

  // OnMOunt
  // State => Update
  // Cleanup => UnMount
  // Side Effect Api Calls or Browser Dom
  // useEffect(() => { 
  //   fetch("https://jsonplaceholder.typicode.com/users")
  //   .then(res => res.json())
  //   .then(data => setUsers(data))
  // } , [])

  return ( 
    <>
        <button onClick={() => setTitle("React Project")}>Change Title</button>
        <h1 className={title ? "success" : ""}> {title} </h1>
        <button onClick={() => setCount(count + 1)}>Increment Count</button>
        {/* Conditional Rendering */}
        {
          users.length > 0 && 
          <ul>
            {
              // Lists And Keys
              users.map(user => (
                <li key={user.id}>{user.username}</li>
              ))
            }
          </ul>
        }
    </>
   );
}

export default App;