import { Routes , Route } from "react-router-dom";
import Footer from "./components/Footer/Footer";
import Navbar from "./components/Navbar/Navbar";
import Home from "./pages/Home";
import Create from "./pages/Create";
import Error404 from "./components/Error404/Error404";
import Details from "./pages/Details";
import Edit from "./pages/Edit";
import Contact from "./pages/Contact";

function App() {
  return ( 
    <>
      <Navbar />
        <Routes>
          {/* localhost:5173 => / base url */}
          <Route path="/" element={<Home />} />
          {/* /create => localhost:5173/create */}
          <Route path="/create" element={<Create />} />
          {/* Details */}
          <Route path="/details/:id" element={<Details />} />
          {/* Edit */}
          <Route path="/edit/:id" element={<Edit />} />
          {/* Contact Page */}
          <Route path="/contact" element={<Contact />} />
          {/* Not Match  */}
          <Route path="*" element={<Error404 />} />
        </Routes>
      <Footer />
    </>
   );
}

export default App;