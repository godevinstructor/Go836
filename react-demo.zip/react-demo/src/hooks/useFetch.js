import { useState , useEffect } from "react";

const useFetch = (url) => { 
    const [data , setData] = useState([])

    useEffect(() => { 
        fetch(url)
        .then(res => res.json())
        .then(body => setData(body))
        .catch(err => console.error(err.message))
    } , [])

    return data;
}

export default useFetch;