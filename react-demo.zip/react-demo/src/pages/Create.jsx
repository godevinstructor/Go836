import { useEffect , useState } from "react";
import { addCourse } from "../services/courses.service";
import { useNavigate } from "react-router-dom";
import MasHeading from "../components/MasHeading/MasHeading";
function Create() {

    const [course , setCourse] = useState({
        title : "" , 
        price : "" , 
        instructor : "" , 
        desc : ""
    })


    const navigate = useNavigate()

    const onSubmitForm = (event) => { 
        // Prevent Default Submit
        event.preventDefault();
        if(course.title == "" || course.price == "" ||
             course.instructor == "" || course.desc == "") { 
            alert("All Inputs Are Required")
        }else { 
            addCourse(course)
            .then(() => { 
                alert("Courses Added Successfully")
                // Redirect To / 
                navigate("/")
            })
        }
    }
    return ( 
        <>
           <MasHeading message="Create New Course"/>
            <section className="my-5 mx-auto w-50 container">
                <form onSubmit={onSubmitForm}>
                    <div className="form-group my-2">
                        <label htmlFor="title" className="fw-bold">Course title</label>
                        <input type="text" id="title" className="form-control" 
                        onChange={(event) => setCourse({...course , title : event.target.value})}
                        />
                    </div>
                    <div className="form-group my-2">
                        <label htmlFor="price" className="fw-bold">Course Price</label>
                        <input type="text" id="price" className="form-control" 
                        onChange={(event) => setCourse({...course , price : event.target.value})}
                        />
                    </div>
                    <div className="form-group my-2">
                        <label htmlFor="instructor" className="fw-bold">Course Instructor</label>
                        <input type="text" id="instructor" className="form-control" 
                        onChange={(event) => setCourse({...course , instructor : event.target.value})}
                        />
                    </div>
                    <div className="form-group my-2">
                        <label htmlFor="desc" className="fw-bold">Course Description</label>
                        <textarea id="desc" className="form-control"
                        onChange={event => setCourse({...course , desc : event.target.value})}
                        ></textarea>
                    </div>
                    <input type="submit" value="Add Course" className="btn btn-dark mt-3" />
                </form>
            </section>
        </>
     );
}

export default Create;