import { useEffect , useState } from "react";
import { deleteCourse, getCourses } from "../services/courses.service";
import { Link } from "react-router-dom";
import MasHeading from "../components/MasHeading/MasHeading";
import Table from "../components/Table/Table";
 export function removeCourse(id) { 
        const confirmDelete = window.confirm("Are U Sure ?")
        if(confirmDelete) { 
            deleteCourse(id)
            .then(() => { 
                alert("Course Deleted ")
            })
        }
    }
function Home() {
    const [courses , setCourses] = useState([])

    useEffect(() => { 
        getCourses()
        .then(res => setCourses(res.data))
        .catch(err => console.error(err.message))
    } , [courses])

    // Filter Instead of dependency useEffect
    return ( 
        <>
            <MasHeading message="Courses List" />
            <section className="my-5 text-center">
                <div className="container">
                    <Table courses={courses}/>
                </div>
            </section>
        </>
     );
}



export default Home;