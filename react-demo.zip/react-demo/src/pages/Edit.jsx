import { useEffect , useState} from "react";
import MasHeading from "../components/MasHeading/MasHeading";
import { getCourse, updateCourse } from "../services/courses.service";
import { useNavigate, useParams } from "react-router-dom";
import Swal from "sweetalert2";
function Edit() {
    const [course , setCourse] = useState({
        title : "" , 
        price : "" , 
        instructor : "" , 
        desc : ""
    });
    const {id} = useParams()
    const navigate = useNavigate()
    useEffect(() => {
        getCourse(id)
        .then(res => setCourse(res.data))
     } , [])

    const onSubmitForm = (event) => { 
        event.preventDefault();

        if(course.title === "" || course.price === "" || 
            course.instructor === "" || course.desc === "") { 
            alert('All Input Are Required')
        }else { 
            updateCourse(id , course) 
                .then(() => { 
                Swal.fire({
                position: "top-start",
                icon: "success",
                title: "Course Updated Successfully",
                showConfirmButton: false,
                timer: 4000
                });
                navigate("/")
            })
        }
     }

    return ( 
        <>
           <MasHeading message="Edit Course"/>

            <section className="my-5 mx-auto w-50 container">
                <form onSubmit={onSubmitForm}>
                    <div className="form-group my-2">
                        <label htmlFor="title" className="fw-bold">Course title</label>
                        <input type="text" id="title" 
                        className="form-control" 
                        value={course.title}
                        onChange={e => setCourse({...course , title : e.target.value})}
                        />
                    </div>
                    <div className="form-group my-2">
                        <label htmlFor="price" className="fw-bold">Course Price</label>
                        <input type="text" id="price" value={course.price}
                        className="form-control"
                        onChange={e => setCourse({...course , price : e.target.value})}
                        />
                    </div>
                    <div className="form-group my-2">
                        <label htmlFor="instructor" className="fw-bold">Course Instructor</label>
                        <input type="text" id="instructor" 
                        className="form-control" 
                        value={course.instructor}
                        onChange={e => setCourse({...course , instructor : e.target.value})}
                        />
                    </div>
                    <div className="form-group my-2">
                        <label htmlFor="desc" className="fw-bold">Course Description</label>
                        <textarea id="desc" className="form-control"
                        value={course.desc}
                        onChange={e => setCourse({...course , desc : e.target.value})}
                        ></textarea>
                    </div>
                    <input type="submit" value="Edit Course"
                     className="btn btn-secondary mt-3" />
                </form>
            </section>
        </>
     );
}

export default Edit;