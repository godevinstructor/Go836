import { useEffect, useRef } from "react";
import MasHeading from "../components/MasHeading/MasHeading";
import emailjs from '@emailjs/browser';

function Contact() {
    const emailInputRef = useRef()
    const form = useRef();
    useEffect(() => { 
        const mailInput = emailInputRef.current
        mailInput.focus()
    } , [])

    const sendEmail = (e) => {
    e.preventDefault();

    emailjs
      .sendForm('service_3zjfskl', 'template_o02zxcz', form.current, {
        publicKey: '4DiyVLTWTlHPnbDm5',
      })
      .then(
        () => {
          alert("Email Sent Successfully")
        },
        (error) => {
          console.log('FAILED...', error.text);
        },
      );
  };
    return ( 
        <>
            <MasHeading message="Contact Us"/>

            <section className="my-5 w-50 container mx-auto">
                <form action="" ref={form}
                 onSubmit={sendEmail}>
                    <div className="form-floating mb-3">
                        <input type="email" className="form-control" id="email"
                         placeholder="Email Address" name="user_email"
                         ref={emailInputRef}
                         />
                        <label htmlFor="email">Email address</label>
                    </div>
                    <div className="form-floating">
                        <textarea className="form-control" name="message"
                         placeholder="Message" id="message" 
                         style={{height: "100px"}}></textarea>
                        <label htmlFor="message">Message</label>
                    </div>
                    <input type="submit" value="Send Message" className="btn btn-dark mt-2" />
                </form>
            </section>
        </>
     );
}

export default Contact;