import { useEffect, useState } from "react";
import MasHeading from "../components/MasHeading/MasHeading";
import { useParams } from "react-router-dom";
import { getCourse } from "../services/courses.service";
import { Link } from "react-router-dom";
function Details() {
    const {id} = useParams()

    const [course , setCourse] = useState({})

    useEffect(() => { 
        getCourse(id)
        .then(res => setCourse(res.data))
        .catch(err => console.error(err.message))
    } , [])

    return ( 
        <>
            <MasHeading message="Course Details" />

            <section className="container w-50 my-5 mx-auto text-center">
                <div class="card">
                <div class="card-header">
                    {course.title}
            </div>
            <div class="card-body">
                <h5 class="card-title">
                    Course Price {course.price} <br />
                    Created By <span style={{color : "red"}}>{course.instructor}</span>
                </h5>
                <p class="card-text">{course.desc}</p>
                <Link to="/" class="btn btn-dark mt-2">Return To Home</Link>
            </div>
            </div>
            </section>
           
        </>
     );
}

export default Details;