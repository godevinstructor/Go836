function MasHeading({message}) {
    return (
        <>
            <h1 className="text-center bg-dark text-center rounded text-white
            w-50 py-3 mx-auto my-5">
                {message}
            </h1>
        </>
      );
}

export default MasHeading;