function Footer() {
    return ( 
        <>
            <footer className="bg-light mt-5 text-black text-center py-3">
                <p className="fs-5">
                    Copyright &copy; 2026 All Right Reserved
                </p>
            </footer>
        </>
     );
}

export default Footer;