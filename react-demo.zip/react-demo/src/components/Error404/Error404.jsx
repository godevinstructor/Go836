function Error404() {
    return (
        <>
            <div className="container w-50 mx-auto my-5">
                <div className="alert alert-warning text-center my-5">
                    <h2 className="fs-3">Page Not Found</h2>
                    <p className="fs-5">
                        We couldn't find what you were looking for.
                        If you think this is a mistake, please open an issue so we can fix it.
                    </p>
                </div>
            </div>
        </>
    );
}

export default Error404;