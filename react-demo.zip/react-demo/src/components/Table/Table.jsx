import { Link } from "react-router-dom";
import { removeCourse } from "../../pages/Home";
function Table({courses}) {
    return ( 
        <>
              <table className="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Price</th>
                                <th>Instructor</th>
                                <th>Description</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                courses.map(course => (
                                    <tr key={course.id}>
                                        <td>{course.id}</td>
                                        <td>{course.title}</td>
                                        <td>{course.price}</td>
                                        <td>{course.instructor}</td>
                                        <td>{course.desc}</td>
                                        <td>
                                            <Link to={`/details/${course.id}`} className="btn btn-sm btn-primary mx-1">Show</Link>
                                            <Link to={`/edit/${course.id}`} className="btn btn-sm btn-success mx-1">Edit</Link>
                                            <button className="btn btn-sm btn-danger mx-1"
                                            onClick={() => removeCourse(course.id)}>Delete</button>
                                        </td>
                                    </tr>
                                ))
                            }
                        </tbody>
                    </table>
        </>
     );
}

export default Table;