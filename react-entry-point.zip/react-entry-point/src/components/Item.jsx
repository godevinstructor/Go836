import { useContext } from "react";
import { TitleContext } from "../App";

function Item() {
    const {title , setTitle} = useContext(TitleContext)
    return ( 
        <>
            {/* <button onClick={() => setTitle("React Advanced Course")}>
                Change Title</button>
            <h1> {title} </h1> */}

        </>
     );
}

export default Item;