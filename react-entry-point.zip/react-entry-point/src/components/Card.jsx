import Item from "./Item";
function Card() {
    return ( 
        <>
            <Item/>
        </>
     );
}

export default Card;