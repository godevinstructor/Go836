import { useContext } from "react";
import Card from "./Card";
import { ThemeContext } from "../context/ThemeContext";

function Products() {
    const {theme , toggleTheme} = useContext(ThemeContext)
    return ( 
        <>
            <section className="text-center my-5"
            style={{
                background : theme === "dark" ? "#2d2d2d" : "#fff",
                color : theme === "dark" ? "#fff" : "#2d2d2d"
            }}>
                <button onClick={toggleTheme}>Toggle Theme</button>
                <h1>React Demo</h1>
                <p>Lorem ipsum dolor sit amet.</p>
            </section>
        </>
     );
}

export default Products;