import { useContext } from "react";
import { ThemeContext } from "../context/ThemeContext";

function Home() {
    const {theme , toggleTheme} = useContext(ThemeContext)
    return (  
        <>

        </>
    );
}

export default Home;