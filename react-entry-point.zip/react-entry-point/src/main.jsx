import App from "./App";
import { createRoot } from "react-dom/client";
import "./index.css"

import 'bootstrap/dist/css/bootstrap.min.css';
import '@popperjs/core/dist/umd/popper.min.js';
import 'bootstrap/dist/js/bootstrap.min.js';

import { BrowserRouter } from "react-router-dom";
import { ThemeProvider } from "./context/ThemeContext";


createRoot(document.getElementById('root')).render(
   <BrowserRouter>
       <ThemeProvider>
          <App />
       </ThemeProvider>
   </BrowserRouter>
)
