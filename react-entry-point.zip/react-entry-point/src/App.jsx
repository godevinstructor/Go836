import Products from "./components/Products";
import { createContext, useState } from "react";

export const TitleContext = createContext()

function App() { 
  const [title , setTitle] = useState("React App")
  return(
    <>
        {/* <TitleContext.Provider value={{title , setTitle}}>
            <Products />
        </TitleContext.Provider> */}
        <Products />
    </>
  )
}

export default App;