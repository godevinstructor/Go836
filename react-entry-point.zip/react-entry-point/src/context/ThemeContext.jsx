import { useState , createContext } from "react";

export const ThemeContext = createContext(null)
// Provide => values
// Consumer => useContext() 

export function ThemeProvider({children}) { 
    const [theme , setTheme] = useState("light")

    const toggleTheme = () => { 
        setTheme((prevVal) => prevVal === "light" ? "dark" : "light")
    }
// setTheme("light")
    return (
        <ThemeContext.Provider value={{theme , toggleTheme}}>
            {children}
        </ThemeContext.Provider>
    )
}