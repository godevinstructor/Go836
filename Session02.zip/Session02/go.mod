module starter-app

go 1.27.0
