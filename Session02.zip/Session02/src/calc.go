package src

// func greeting(user string) string {
// 	return "Welcome"
// }

func Add(num1 , num2 int) int { 
	return num1 + num2
}

func Calculator(num1 , num2 int) (int , int) { 
	return num1 * num2 , num1 / num2
}  