package main

import "fmt"


func main() { 

	// var students [4]string = [4]string{"Mahmoud" , "Ahmed" , "Waheed" , "Huda"}

	// // var name [Size]type
	// students := [...]string{"Mahmoud" , "Ahmed" , "Waheed" , "Huda"}
	// fmt.Println(len(students))

	// for i:=0 ; i < len(students); i++ {
	// 	fmt.Println(students[i])
	// }

	// for _ , value := range students { 
	// 	fmt.Println(value)
	// }

	// students[0] = "Mahmoud"
	// students[1] = "Ahmed"
	// students[2] = "Waheed"
	// students[3] = "Huda"

	// salaries := [3]int{1000 , 2000 , 3000}

	// numbers := []int{4 , 5 , 6}

	// nums := make([]int, 5)

	
}